<?php

/*
@name     OpenCart
@package  seo_common_urls (Seo Common Urls),
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.2
@link     https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=45444
@link     https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=45444
@link     https://github.com/ocmod-space/ocmod-seo-common-urls
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-seo-common-urls/main/LICENSE.txt
*/

$_['heading_title'] = '/<a href="https://www.ocmod.space/">ocmod.space</a>/seo_common_urls';
$_['text_extension'] = 'Розширення';
$_['text_edit'] = 'Редагування параметрів модуля <b>Seo Common Urls</b>';
$_['text_success'] = 'Готово! Параметри модуля <b>/ocmod.space/seo_common_urls</b> збережено.';
$_['error_permission'] = 'Увага! Недостатньо прав для редагування параметрів модуля<b>/ocmod.space/seo_common_urls</b>!';
$_['text_made'] = '<code>Зроблено з <i class="fa fa-heart" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> в Україні</code>';
$_['text_about'] = 'Модуль призначає ключові слова SEO для загальних URL-адрес.';
