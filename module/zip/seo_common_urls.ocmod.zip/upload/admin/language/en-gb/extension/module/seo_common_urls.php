<?php

/*
@name     seo_common_urls
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.2
@link     https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=45444
@link     https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=45444
@link     https://github.com/ocmod-space/ocmod-seo-common-urls
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-seo-common-urls/main/LICENSE.txt
*/

$_['heading_title'] = '/ocmod.space/seo_common_urls';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>Seo Common Urls</b>';
$_['text_success'] = 'Success! The <b>/ocmod.space/seo_common_urls</b> module settings have been saved.';
$_['error_permission'] = 'WARNING! You do not have write permissions for the module <b>/ocmod.space/seo_common_urls</b>.';
$_['text_made'] = '<code>Made with <i class="fa fa-heart-o" aria-hidden="true" style=" background: -webkit-linear-gradient(#0066cc, #ffcc00); -webkit-background-clip: text; -webkit-text-fill-color: transparent;"></i> in Ukraine</code>';
$_['text_about'] = 'The module assigns SEO keywords for the common URLs.';
