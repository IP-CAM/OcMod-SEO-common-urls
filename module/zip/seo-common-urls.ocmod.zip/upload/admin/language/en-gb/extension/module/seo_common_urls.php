<?php

/*
@name     Seo Common Urls
@author   Andrii Burkatskyi, ocmod.space@gmail.com
@version  1.0.2
@link     https://www.opencart.com/index.php?route=marketplace/extension/info&extension_id=45444
@link     https://github.com/ocmod-space/ocmod-seo-common-urls
@licence  https://raw.githubusercontent.com/ocmod-space/ocmod-seo-common-urls/main/EULA.txt
*/

$_['heading_title'] = '#ocmod.space: seo-common-urls';
$_['text_extension'] = 'Extensions';
$_['text_edit'] = 'Edit <b>Seo Common Urls</b>';
$_['text_made'] = 'Made with <i class="fa fa-heart-o" aria-hidden="true"></i> in Ukraine';
$_['text_about'] = 'The module assigns SEO keywords for the common URLs.';
